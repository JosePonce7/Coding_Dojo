function logout(element){
    element.textContent="Logout";
}

function hide(element){
    element.remove();
}